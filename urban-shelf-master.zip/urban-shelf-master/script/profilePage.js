window.onload = function () {
    // CALL FUNCTIONS
    loginUser();
    allowLogout();
    changeDefaultPhoto();
    showUserNotifications();
}