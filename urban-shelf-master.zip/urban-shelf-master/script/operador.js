window.onload = function() {
    loginUser();
    allowLogout();

    getStoredBooks();
}
