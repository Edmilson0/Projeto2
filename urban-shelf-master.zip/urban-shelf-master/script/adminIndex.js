window.onload = function () {
    loginUser();
    allowLogout();

    displayMapMarkes();
}