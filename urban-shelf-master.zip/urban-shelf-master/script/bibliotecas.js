window.onload = function () {
    displayMapMarkes();
    loginUser();
    allowLogout();
    getStoredRequisitions();
    showUserNotifications();
}